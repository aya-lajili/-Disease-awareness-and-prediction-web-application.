/*const router = require('express').Router();
const recomController = require('../controllers/RecommandationController');


router.get('/event', recomController.readRecomUserEvent);
router.get('/', recomController.readRecomUser);
router.post('/', recomController.createRecomUser);



module.exports = router;*/
