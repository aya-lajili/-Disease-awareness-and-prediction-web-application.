/*const mongoose = require('mongoose');

const RecommandationSchema = mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'},
    evenement: [ {  
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Evenement' } ] 


  
});
const Recommandation = mongoose.model('Recommandation', RecommandationSchema)
module.exports = Recommandation ;*/