
import{ React,useState,  useContext } from 'react';
import { useSelector } from "react-redux";
import ImageSlider from "./avatar/Slider";
import { UidContext } from '../AppContext';
import Progressbar from '../variables/Progress_bar';

import {
  Button,
  Card,
  CardHeader,
  CardBody,
  CardFooter,
  CardText,
  FormGroup,
  UncontrolledDropdown,
  Form,
  Label,
  Input,
  DropdownMenu,
  Row,
  Col,
  DropdownItem,
  UncontrolledTooltip,
  DropdownToggle,
  Table,
} from "reactstrap";

function UserProfile() {


  const uid = useContext(UidContext);
  const userData = useSelector((state)=> state.userReducer);

  const [checked, setChecked] = useState(false);
  const [checkedd, setCheckedd] = useState(false);
  const [checkeddd, setCheckeddd] = useState(false);
  const [checkedddd, setCheckedddd] = useState(false);
  const [checkeddddd, setCheckeddddd] = useState(false);
  const [checkedddddd, setCheckedddddd] = useState(false);

  const [ reslt, setRes] = useState(0);

 
const handleChange = () => {
  console.log(checked)
  setChecked(!checked);
  if (checked===false){
    console.log("+1");
    setRes(reslt+16)
  }else{console.log("-1");
        setRes(reslt-16)}
  

   
};
 /*  if (x===1){
    console.log(x)
    //setChecked(!checked);
    setx(2)
  }
  else{
    if(checked){
      setChecked(!checked);
      setProg(prog + 16)
      console.log(prog) 
    }
    else{
      setChecked(!checked);
      setProg(prog - 16)
      console.log(prog)};
    
      } */     

     


  

const handleChangee = () => {
  console.log(checkedd)
  setCheckedd(!checkedd);
  if (checkedd===false){
    console.log("+1");
    setRes(reslt+16)
  }else{console.log("-1");
        setRes(reslt-16)}
  

   
};
    
      
  
     
    
  const handleChangeee = () => {
    console.log(checkeddd)
  setCheckeddd(!checkeddd);
  if (checkeddd===false){
    console.log("+1");
    setRes(reslt+16)
  }else{console.log("-1");
        setRes(reslt-16)}
  

     
  };

  const handleChangeeee = () => {
    console.log(checkedddd)
    setCheckedddd(!checkedddd);
    if (checkedddd===false){
      console.log("+1");
      setRes(reslt+16)
    }else{console.log("-1");
          setRes(reslt-16)}
    
  
  };

  const handleChangeeeee = () => {
    console.log(checkeddddd)
  setCheckeddddd(!checkeddddd);
  if (checkeddddd===false){
    console.log("+1");
    setRes(reslt+16)
  }else{console.log("-1");
        setRes(reslt-16)}
  
   
    
  };

  const handleChangeeeeee = () => {
    console.log(checkedddddd)
    setCheckedddddd(!checkedddddd);
    if (checkedddddd===false){
      console.log("+1");
      setRes(reslt+16)
    }else{console.log("-1");
          setRes(reslt-16)}
    
  };
















  return (
    <>
      <div className="content">
        <Row>
          <Col md="12">
            <Card>
              <CardHeader>
                <h5 className="title">Edit Profile</h5>
              </CardHeader>
              <CardBody>
                <ImageSlider />
              </CardBody>
              <CardFooter>
                

              </CardFooter>
            </Card>
          </Col>
          
        </Row>
       
      </div>
    </>
  );
}

export default UserProfile;
