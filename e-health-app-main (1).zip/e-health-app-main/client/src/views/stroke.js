import { Chat, addResponseMessage,addLinkSnippet, addUserMessage} from 'react-chat-popup';
import logo from "../chatbot.jpg";
import React from 'react'
import axios from 'axios'
class Stroke extends React.Component
{
    state ={
        chat : [],
        msg : '',
        response:'',
        choices:['stroke','heartdisease','diabetes'],
        choice : '',
        StrokeDone : false,
        HeartDone : false,
        DiabetesDone : false
    }
    componentDidMount() {
        addResponseMessage("Hi im your Ai chatbot , what test do you want to do ?");
        addResponseMessage("Please select one of the folowing")
        addResponseMessage("stroke,heartdisease,diabetes")
      }
    handleNewUserMessage = (newMessage) => {
        console.log(`New message incomig! ${newMessage}`);
        // Now send the message throught the backend API
        if (newMessage=="stroke")
        this.state.choice=newMessage
        else if (newMessage=="diabetes")
        this.state.choice=newMessage
        else if (newMessage=="heartdisease")
        this.state.choice=newMessage
        if (this.state.choice ==="stroke" && this.state.StrokeDone===false)
        {
            axios.post('http://127.0.0.1:5000/stroke',{"msg":newMessage})
            .then(res=>
                {
                  if (res.data.done===false)
                    
                  {console.log(res);
                    addResponseMessage(String(res.data.data));
                    let ch=this.state.chat;
                    ch.push({from:'our',msag:this.state.msg});
                    ch.push({from:'cb',msag:res.data});
                    this.setState({chat:ch});
                    this.setState({msg:""});
                  }
                    if (res.data.done)
                  {
                    addResponseMessage("your chance of having a stroke is:"+" "+(res.data.data)*100+"%");
                    this.state.StrokeDone=true
                    console.log(this.state.HeartDone===false && this.state.DiabetesDone===false)
                    console.log(this.state.DiabetesDone)
                    addResponseMessage("Please select one of the folowing")
                    if(this.state.HeartDone===false && this.state.DiabetesDone===false) 
                    addResponseMessage("heartdisease,diabetes")
                    if (this.state.HeartDone===false && this.state.DiabetesDone===true)
                    addResponseMessage("heartdisease")
                    if (this.state.HeartDone===true && this.state.DiabetesDone===false)
                    addResponseMessage("diabetes")
                  }
                })
            .catch(err=>{console.log(err);
            });
      }
      else if (this.state.choice ==="diabetes" && this.state.DiabetesDone===false)
      {
        console.log("Diabetes");
          axios.post('http://127.0.0.1:5000/diabets',{"msg":newMessage})
          .then(res=>
              {
                if (res.data.done===false)
                {
                  console.log(res);
                  addResponseMessage(String(res.data.data));
                  let ch=this.state.chat;
                  ch.push({from:'our',msag:this.state.msg});
                  ch.push({from:'cb',msag:res.data});
                  this.setState({chat:ch});
                  this.setState({msg:""});
                }
                  if (res.data.done)
                    {
                    this.state.DiabetesDone=true
                    addResponseMessage("your chance of having diabetes is:"+" "+(res.data.data)*100+"%");
                    addResponseMessage("Please select one of the folowing")
                    if(this.state.HeartDone===false && this.state.StrokeDone===false) 
                    addResponseMessage("heartdisease,stroke")
                    if (this.state.HeartDone===false && this.state.StrokeDone===true)
                    addResponseMessage("heartdisease")
                    if (this.state.HeartDone===true && this.state.StrokeDone===false)
                    addResponseMessage("stroke")
                  }
                  
              })
          .catch(err=>{console.log(err);
          });
    }
    else if (this.state.choice ==="heartdisease" && this.state.HeartDone===false)
    {
      console.log("heartdisease")
        axios.post('http://127.0.0.1:5000/disease',{"msg":newMessage})
        .then(res=>
            {
              if(res.data.done===false)
              {
                console.log(res);
                addResponseMessage(String(res.data.data));
                let ch=this.state.chat;
                ch.push({from:'our',msag:this.state.msg});
                ch.push({from:'cb',msag:res.data});
                this.setState({chat:ch});
                this.setState({msg:""});
              }
                if (res.data.done)
                  {
                    console.log(res);
                    this.state.HeartDone=true
                    addResponseMessage("your chance of having a heartdisease is:"+" "+(res.data.data)*100+"%");
                    addResponseMessage("Please select one of the folowing")
                    if(this.state.StrokeDone===false && this.state.DiabetesDone===false) 
                    addResponseMessage("stroke,diabetes")
                    if (this.state.StrokeDone===false && this.state.DiabetesDone===true)
                    addResponseMessage("stroke")
                    if (this.state.StrokeDone===true && this.state.DiabetesDone===false)
                    addResponseMessage("diabetes")
                  }
                
            })
        .catch(err=>{console.log(err);
        });
  }
  else if (this.state.StrokeDone===true && this.state.HeartDone===true && this.state.DiabetesDone===true)
  {
    addResponseMessage("Thank you for Patience and Please proceed to the Calendar")
  }
    }
    render()
    {
        return (
            <div>
            <Chat 
            handleNewUserMessage={this.handleNewUserMessage}
            profileAvatar={logo}
            title="Ai Chatbot for Disease Prediction"
            subtitle="And my cool subtitle"
            //fullScreenMode
            styles={{"background": "black"}}
            />
            </div>
        )
    }
}
export default Stroke;