import React, { Component } from 'react';
import ChatBot from 'react-simple-chatbot';
import axios from 'axios'
import { createTrue } from 'typescript';
//import Review from './Review';

import {
  Button,
  Card,
  CardHeader,
  CardBody,
  CardFooter,
  CardText,
  FormGroup,
  UncontrolledDropdown,
  Form,
  Label,
  Input,
  DropdownMenu,
  Row,
  Col,
  DropdownItem,
  UncontrolledTooltip,
  DropdownToggle,
  Table,
} from "reactstrap";

class SimpleForm extends Component {
  state={
    msg:"",
  }
  BotResponse (usermsg) 
  {
    axios.post('http://127.0.0.1:80/user',{"msg":usermsg})
    .then(res=>
        {
            console.log(res);
            return res.data            
        })
    .catch(err=>{console.log(err);
    });
  }
    render() {
      return (




        <div className="content">
        <Row>
          
         
         




          <Col  md="8">
            <Card className="card-user">
              <CardBody>
                <CardText />
                <img
                      alt="..."
                      style={{height: '150%'}}
                      src={require("assets/img/chatpsy.png").default}
                    />

              </CardBody>
              <CardFooter>
                
              </CardFooter>
            </Card>
          </Col>
          <Col md="6">
          <div className = "bot" style ={{ bottom:'0',right : '0',position: 'fixed',width: '350px'}}>
        <ChatBot
        headerTitle="Speech Recognition For mental Health Check"
        recognitionEnable={true}
        speechSynthesis={{ enable: true, lang: 'en' }}
        steps={[
          {
            id: '1',
            message: 'What is your name?',
            trigger: '2',
          },
          {
            id: '2',
            user: true,
            trigger: '3',
          },
          {
            id: '3',
            message: 'Hi {previousValue}, nice to meet you! Tell me whats wrong',
            trigger : '4',
          },
          {
            id: '4',
            user:true,
           trigger : '5'
          },
          {
            id: '5',
            message:"Depression (major depressive disorder) is a common and serious medical illness that negatively affects how you feel, the way you think and how you act. Fortunately, it is also treatable. Depression causes feelings of sadness and/or a loss of interest in activities you once enjoyed." ,
            trigger : '6'
          },
          {
            id:'6',
            user : true,
            trigger :'7'
          },
          {
            id: '7',
            message:"It can lead to a variety of emotional and physical problems and can decrease your ability to function at work and at home.Depression is among the most treatable of mental disorders. Between 80% and 90% of people with depression eventually respond well to treatment.",
            trigger:'8' 
          },
          {
            id :'8',
            user : true,
            trigger : '9'
          },
          {
            id :'9',
            message :" Almost all patients gain some relief from their symptoms.There are a number of things people can do to help reduce the symptoms of depression. For many people, regular exercise helps create positive feeling and improves mood. Getting enough quality sleep on a regular basis, eating a healthy diet and avoiding alcohol (a depressant) can also help reduce symptoms of depression.",
            end : true
          }
        ]}
      />
      </div>


          

          </Col>

         


        </Row>
        
      </div>









       
      );
    }
  }
  
  export default SimpleForm;