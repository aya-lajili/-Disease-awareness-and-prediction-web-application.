import React from 'react';
import { Link } from 'react-router-dom';
import ImageSlider from "../avatar/Slider";
import "../avatar/aa.css"

const FormSuccess = () => {
    return (
        <div className="form-content-right">
            <div className='form-success'>
              You are now registered!<Link to='/login'>Login Here</Link>
            </div> 
            
            
            {/*<div className="container mt-5 carousel">
                <h2 className="slider_title">Choose Your Avatar</h2>
                <ImageSlider />
            </div>*/}

            <img  src={require('assets/img/doctor2.png').default}  alt="success-image"
             className="form-img-2" />

            
        </div>
        
        
    )
}

export default FormSuccess;